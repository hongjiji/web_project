<!DOCTYPE html>
<html>
	<head>
		<title>Tank Simulator</title>
		<style type="text/css">
			canvas{border: 1px solid black};
		</style>
		<script>
			
			
		</script>
	</head>
	<body>
		<div style ="width: 50%; border:1px; float:left;">
			
			<!--<img src="tank.PNG" style = "position:absolute; left:20px; top:50px; cursor:pointer; cursor:hand; border:0" onmousedown="listener(event,this)">-->
			<canvas id="canvas" width="920" height="700">
			</canvas>
		</div>
		<div style ="width: 39%; border:1px; float:left;">
			<?php 
                    $handle = fopen("./input.txt", "r");   //Matched List �����Ϳ��� ����
                    if(!$handle) die("NotFound!");
                    for($i=0; !feof($handle); $i++){                //�ε� �� �������� ��ü ���� �о��
                        $buffer[$i] = fgets($handle);
                        $values = explode(",",$buffer[$i]);        //"," Delimiter
                        if ($values[0]=="tank"+$i){                //"Subject"�� ���Ե� ������ ���
                            for($j=1; $j<count($values);$j++){     //index, subject, object�� ������ �� ����(Matchlist) MatchList�� ������
                                if($j==count($values)-1){          //�������̶�� �޸� ����
                                    echo $values[$j]; 
                                }
                                else{
                                    echo "$values[$j],&nbsp;";     // �������� �ƴ϶�� �޸�, ���� �߰�
                                }
                            }
                        }
                        break;
                    }
                    fclose($handle);
                    echo   "<table>
                            <tr>
                                <td>
                                    <font size=5 color=white><b>Range</b></font>
                                </td>
                                <td>
                                    <font size=5 color=white>&nbsp;&nbsp;:&nbsp;&nbsp;$values[2]</font>
                                </td>
                                <td>
                                    <font size=5 color=white>&nbsp;&nbsp&nbsp;&nbsp<b>Triple Count</b>&nbsp;&nbsp:&nbsp;&nbsp $values[0]</font>
                                </td>
                            </tr>
                            </table>";
                ?>
			<table border = "1px" width=100% height=100% style = "font-family:Arial; font-size:30px">
				<tr>
					<td width="12%"><img src="1.png"></td>
					<td>object 1 : Tank 1 <br> 
					Set option : <br>
					<font size = 4>start x :</font><input type="text" id="tx1" value=200 />  <font size = 4>grad x :</font><input type="text" id="tgx1" value=0 /> <br>
					<font size = 4>start y :</font><input type="text" id="ty1" value=300 />  <font size = 4>grad y :</font><input type="text" id="tgy1" value=70 /> <br>
					<font size = 4>distance :</font><input type="text" id="dist1" value=200 />
					</td>
				</tr>
				<tr>
					<td width="12%"><img src="2.png"></td>
					<td>object 2 : Tank 2 <br> 
					Set option : <br>
					<font size = 4>start x :</font><input type="text" id="tx2" value=800 /><font size = 4>grad x :</font><input type="text" id="tgx2" value=-100 /> <br>
					<font size = 4>start y :</font><input type="text" id="ty2" value=40 /><font size = 4>grad y :</font><input type="text" id="tgy2" value=-10 /> <br>
					<font size = 4>distance :</font><input type="text" id="dist2" value=300 />
					</td>
				</tr>
				<tr>
					<td width="12%"><img src="3.png"></td>
					<td>object 3 : Tank 3 <br> 
					Set option : <br>
					<font size = 4>x :</font><input type="text" id="tx3" value=400 /><font size = 4>grad x :</font><input type="text" id="tgx3" value=110 /> <br>
					<font size = 4>y :</font><input type="text" id="ty3" value=400 /><font size = 4>grad y :</font><input type="text" id="tgy3" value=220 /> <br> 
					<font size = 4>distance :</font><input type="text" id="dist3" value=400 />
					</td>
				</tr>
				
		
			</table>
			<div>
			&nbsp;
			</div>
			<button id="button2"><font size=7>Set-up</font></button>&nbsp;&nbsp;&nbsp;
			<button id="button1" size=7><font size=7>Start</font></button>&nbsp;&nbsp;&nbsp;
			<button id="button3" size=7><font size=7>Pause</font></button>
		</div>
		<div id="get_script" style="position:absolute;bottom:60px;">
			<table id="distTable">
			
			</table>
		</div>
		<script src="js/tanksimul.js"></script>
	</body>
</html>