var canvas;
var ctx;
var arBall = new Array();
var NUM = 3;
var oldTime;
var t1 = new Image();
t1.src = "tank2.jpg";
var back = new Image();
back.src = "map.png";
var endtank = new Array();
endtank.push({
	tank1x:700,tank1y:800,
	tank2x:400,tank2y:200,
	tank3x:600,tank3y:300
})



window.onload = function() {
	canvas = document.getElementById("canvas");
	ctx = canvas.getContext("2d");
	ctx.drawImage(back,0,0,canvas.width,canvas.height);
	button2.onclick = function(){
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		ctx.drawImage(back,0,0,canvas.width,canvas.height);
		arBall = new Array();
		arBall.push({
			id:'tank1',
			x:parseInt(document.getElementById("tx1").value), 
			y:parseInt(document.getElementById("ty1").value),
			dx:1, dy:1,
			vx:parseInt(document.getElementById("tgx1").value),
			vy:parseInt(document.getElementById("tgy1").value),
			r:20,
			fx:parseInt(document.getElementById("tx1").value),
			fy:parseInt(document.getElementById("ty1").value),
			endDist:parseInt(document.getElementById("dist1").value),
			color: ' #A6BEFF'
		})
		arBall.push({
			id:'tank2',
			x:parseInt(document.getElementById("tx2").value), 
			y:parseInt(document.getElementById("ty2").value),
			dx:1, dy:1,
			vx:parseInt(document.getElementById("tgx2").value),
			vy:parseInt(document.getElementById("tgy2").value),
			r:17,
			fx:parseInt(document.getElementById("tx2").value),
			fy:parseInt(document.getElementById("ty2").value),
			endDist:parseInt(document.getElementById("dist2").value),
			color: '#E1A963'
		})
		arBall.push({
			id:'tank3',
			x:parseInt(document.getElementById("tx3").value), 
			y:parseInt(document.getElementById("ty3").value),
			dx:1, dy:1,
			vx:parseInt(document.getElementById("tgx3").value),
			vy:parseInt(document.getElementById("tgy3").value),
			r:19,
			fx:parseInt(document.getElementById("tx3").value),
			fy:parseInt(document.getElementById("ty3").value),
			endDist:parseInt(document.getElementById("dist3").value),
			color: '#7FFFD4'
		})
		//console.log("dsad");
		for(var i = 0; i<NUM; i++){
			var b = arBall[i];
			ctx.beginPath();
			ctx.fillStyle = b.color;
			ctx.strokeStyle="black";
			ctx.arc(b.x, b.y , b.r , 0,2 * Math.PI, true);
			ctx.fill();
			ctx.stroke();
		}
		
	}
	
	//oldTime = getTime();
	button1.onclick = function(){
		var id = setInterval(draw, 10);
		button3.onclick = function(){
			clearInterval(id);
		}
	}
}

// ���� �ð� ����
function getTime() {
	var date = new Date();
	var time = date.getTime();
	delete date;
	return time;
}
function draw() {
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	ctx.drawImage(back,0,0,canvas.width,canvas.height);
	// ��� �ð� ����
	//var ellapse = getTime() -oldTime;
	//oldTime = getTime();
	//ctx.strokeStyle="black"; // Purple path
	//ctx.moveTo(50,100);
	//ctx.lineTo(150,130); 
	//ctx.stroke(); // Draw it
		
	for (var i = 0; i < NUM; i++) {
		var b = arBall[i];
		//console.log();
		ctx.beginPath();
		ctx.fillStyle = b.color;
		ctx.arc(b.x, b.y , b.r , 0,2 * Math.PI, true);
		
		//ctx.drawImage(t1,b.x,b.y,);
		ctx.fill();
		ctx.stroke();
		
		//console.log(b.id[0]);
		//document.getElementById('acc_dist').innerHTML ="<font size=7>"+b.x.toFixed(2)+"</font>";
		if (b.x < b.r) b.dx = 1;
		if (b.x + b.r > canvas.width) b.dx = -1;
		if (b.y < b.r) b.dy = 1;
		if (b.y + b.r > canvas.height) b.dy = -1;
		// �̵��� �Ÿ� ���
		var mx = b.vx / 200;
		var my = b.vy / 200;
		//console.log(b.id,b.x,b.y);
		// ���� ��ġ �̵�
		b.x += mx * b.dx;
		b.y += my * b.dy;
		var movingDistance = calcDist(b.fx,b.fy,b.x,b.y);
		
		
		if(movingDistance > b.endDist){
			b.vx = 0;
			b.vy = 0;
			console.log(arBall[i].id+":"+ movingDistance);
		}else{
			console.log(arBall[i].id+":"+ movingDistance);
		}
	
		
	}
}
function calcDist(x1,y1,x2,y2){		//��Ŭ���� �Ÿ� ���
	var dist = Math.pow(x2-x1,2)+Math.pow(y2-y1,2);
	get_dist = Math.sqrt(dist);
	return get_dist;
	//console.log(get_dist);
	
}
/*
function draw() {
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	ctx.drawImage(back,0,0,canvas.width,canvas.height);
	ctx.drawImage(t1, 100,50,50,50);
	// ��� �ð� ����
	var ellapse = getTime() -oldTime;
	oldTime = getTime();
	
	for (var i = 0; i < NUM; i++) {
		var b = arBall[i];
		ctx.beginPath();
		ctx.fillStyle=b.color;

		//ctx.arc(b.x, b.y , b.r , 0,2 * Math.PI, true);
		ctx.
		ctx.fill();
		ctx.stroke();

		if (b.x < b.r) b.dx = 1;
		if (b.x + b.r > canvas.width) b.dx = -1;
		if (b.y < b.r) b.dy = 1;
		if (b.y + b.r > canvas.height) b.dy = -1;
		
		// �̵��� �Ÿ� ���
		var mx = b.vx * ellapse / 1000;
		var my = b.vy * ellapse / 1000;

		// ���� ��ġ �̵�
		b.x += mx * b.dx;
		b.y += my * b.dy;
	}
}
*/