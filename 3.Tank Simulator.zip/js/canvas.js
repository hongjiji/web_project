var pos = {
	drawable: false,
	x: -1,
	y: -1
};
var canvas, ctx;
var tankX, tankY;

var targetObj;

var t1 = new Image();
t1.src = "tank2.jpg";

var t2 = new Image();
t2.src = "tank2.jpg";

var back = new Image();
back.src = "map.png";
var startX,startY
var iTank_L = 700;		//탱크 위치
var iTank_T = 50;		//탱크 y값
var iTank_W = 50;		//탱크 넓이
var iTank_H = 50;		//탱크 높이
var iX,iY;
var isDrag = false;		//탱크 클릭, 드래그 안할때 flag 값
//위치
var X1 = 0;				
var Y1 = 0;
var X2 = 0;
var Y2 = 0;
var get_dist = 0;
//var oil = 200;
function Tank2 (l,t,w,h){
	this.type = type;
	this.L = l;
	this.T = t;
	this.W = w;
	this.h = h;
	
	
}
window.onload = function(){
	canvas = document.getElementById("canvas");
	ctx = canvas.getContext("2d");
	canvas.addEventListener("mousedown",listener);
	canvas.addEventListener("mousemove",listener);
	canvas.addEventListener("mouseup",listener);
	canvas.addEventListener("mouseout",listener);
	ctx.drawImage(back,0,0,canvas.width,canvas.height);
	bb = canvas.getBoundingClientRect();
	ctx.drawImage(t1, iTank_L, iTank_H,iTank_W,iTank_H);
	
	//ctx.drawImage(t2, iTank_L+100, iTank_H,50,50);
}
function listener(event,obj){		//마우스 입력받는곳
	switch(event.type){
		case "mousedown":
			tank_down(event);
			break;
		case "mousemove":
			tank_move(event);	
			//document.getElementById('position').innerHTML= "";
			//document.getElementById('position').innerHTML= "x :"+"dsds";
			break;
		case "mouseout":
			break;
		case "mouseup":
			tank_up(event);
			//console.log({x: tank_end_x, y: tank_end_y});
			//console.log(tank_start_x)
			break;
	}
}

/*************move tank to drag******************/
/*
function getLeft(o){
	return parseInt(o.style.left.replace('px',''));
}
function getTop(o){
	return parseInt(o.style.top.replace('px',''));
}

function moveDrag(e){
	var e_obj = window.event? window.event: e;
	var dmvx = parseInt(e_obj.clientX+img_L);
	var dmvy = parseInt(e_obj.clientY+img_T);
	targetObj.style.left = dmvx+"px";
	targetObj.style.top = dmvy+"px";
	return false;
}
function startDrag(e,obj){
	targetObj = obj;
	var e_obj = window.event? window.event: e;
	img_L = getLeft(obj) - e_obj.clientX;
	img_T = getTop(obj) - e_obj.clientY;
	console.log({x: event.layerX, y: event.layerY});
	document.onmousemove = moveDrag;
	//document.onmouseup = stopDrag;
	if(e_obj.preventDefault)e_obj.preventDefault();
}
function stopDrag(){
	finishDraw();
	console.log({x: event.layerX, y: event.layerY});
	document.onmousemove = null;
	document.onmouseup = null;
}
*/
function calcDist(x1,y1,x2,y2){		//유클라디언 거리 계산
	var dist = Math.pow(x2-x1,2)+Math.pow(y2-y1,2);
	get_dist = Math.sqrt(dist);
	console.log(get_dist);
	
}
function tank_down(e){		          //tank를 아래로 움직일떄
	initDraw(event);
	startX = e.clientX - bb.left;
	startY = e.clientY - bb.top;
	
	if(startX > iTank_L && startY > iTank_T && startX < (iTank_L+iTank_W) && startY < (iTank_T+iTank_H))
	{	
		X1 = e.layerX;
		Y1 = e.layerY;
		isDrag = true;
	}
}
function tank_move(e){				//tank를 드래그할떄
	if(isDrag){
		if(pos.drawable){
			draw(event);
		}
		m_x = e.layerX;
		m_y = e.layerY;
		calcDist(X1,Y1,m_x,m_y);
		document.getElementById('acc_dist').innerHTML ="<font size=7>"+get_dist.toFixed(2)+"</font>";
		document.getElementById('first_loc').innerHTML ="(700,50)";
		//document.getElementById('oil').innerHTML = "<font size=7>"+oil+"</font>";
		iX = e.clientX - bb.left;
		iY = e.clientY - bb.top;
		tank_draw();
		/*
		oil = oil-1;
		
		if(oil == 0){
			document.getElementById('oil').innerHTML = "<font size=7 color='red'>"+oil+"</font>";
			tank_up(e);
			finishDraw();
		}
		*/
	}
}
function tank_up(e){				//tank에서 손뗄때
	
	
	X2 = e.layerX;
	Y2 = e.layerY;
	
	calcDist(X1,Y1,X2,Y2);
	//console.log(X1);
	//console.log(X2);
	//console.log(get_dist);
	
	document.getElementById('startpos').innerHTML = "X :"+X1+" Y:"+Y1;
	document.getElementById('endpos').innerHTML = "X :"+X2+" Y:"+Y2;
	document.getElementById('position').innerHTML =get_dist;
	
	//oil = 100;
	if(isDrag){
		iX = e.clientX - bb.left;
		iY = e.clientY - bb.top;
		isDrag = false;
		tank_draw();
	}
	X1,X2,Y1,Y2,get_dist= 0;
	
	finishDraw();
}
function tank_draw(){
	ctx.drawImage(back,0,0,canvas.width,canvas.height);
	var coors = getPosition(event);
	ctx.lineTo(coors.X, coors.Y);
	pos.X = coors.X;
	pos.Y = coors.Y;
	
	ctx.stroke();
	ctx.drawImage(t1, iTank_L+iX-startX, iTank_T+iY-startY,iTank_W,iTank_H);
	if(isDrag == false){
		iTank_L = iTank_L + iX - startX;
		iTank_T = iTank_T + iY - startY;
	}
}
/*************draw line******************/
/*
function drawImage(event){
	
	img.onload = function(){
		ctx.drawImage(img, 10, 30);
	}
}
*/
function initDraw(event){
	ctx.beginPath();
	pos.drawable = true;
	var coors = getPosition(event);
	pos.X = coors.X;
	pos.Y = coors.y;
	ctx.lineWidth = 3;
	ctx.strokeStyle = "red";
	ctx.moveTo(pos.X, pos.Y);
}
function draw(event){
	var coors = getPosition(event);
	ctx.lineTo(coors.X, coors.Y);
	pos.X = coors.X;
	pos.Y = coors.Y;
	ctx.lineWidth = 3;
	ctx.strokeStyle = "red";
	ctx.stroke();
}
function finishDraw(){
	pos.drawable = false;
	pos.X = -1;
	pos.Y = -1;
}
function getPosition(event){
	var x = event.pageX - canvas.offsetLeft;
	var y = event.pageY - canvas.offsetTop;
	return {X: x, Y: y};
}
var btnclear = document.getElementById("clear");
		btnclear.onclick = function(e) {
			ctx.clearRect(0, 0, canvas.width, canvas.height);
		}

